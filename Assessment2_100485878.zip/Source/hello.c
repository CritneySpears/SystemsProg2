#include "types.h"
#include "user.h"

int main() {
    printf(1, "Hello, world!\n");
    greeting();
    
    exit();
}